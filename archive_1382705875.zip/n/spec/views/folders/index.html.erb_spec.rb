require 'spec_helper'

describe "folders/index" do
  
end
