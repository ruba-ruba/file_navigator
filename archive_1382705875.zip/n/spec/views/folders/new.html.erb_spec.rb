require 'spec_helper'

describe "folders/new" do

end
