require 'spec_helper'

describe "folders/show" do
  
end
