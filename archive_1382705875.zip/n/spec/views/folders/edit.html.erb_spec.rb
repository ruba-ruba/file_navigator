require 'spec_helper'

describe "folders/edit" do
  
end
