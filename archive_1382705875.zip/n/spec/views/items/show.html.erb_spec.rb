require 'spec_helper'

describe "items/show" do

end
