require 'spec_helper'

describe "items/index" do

end
