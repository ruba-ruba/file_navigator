require 'spec_helper'

describe "items/edit" do

end
