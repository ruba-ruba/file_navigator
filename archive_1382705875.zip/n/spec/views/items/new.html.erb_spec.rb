require 'spec_helper'

describe "items/new" do

end
