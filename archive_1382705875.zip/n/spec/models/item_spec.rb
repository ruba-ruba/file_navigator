require 'spec_helper'

describe Item do
  
end
