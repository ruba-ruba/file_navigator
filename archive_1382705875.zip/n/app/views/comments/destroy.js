$("div[id$=<%= @comment.id %>]").fadeOut();
