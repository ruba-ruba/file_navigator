# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
FileNavigator::Application.config.secret_token = 'd743f66cd20d714722925626285e8429d840cf1ae26f0429697dcf38ca73a7cbf7b9c0fc913347ac8760dc6d0cb63fc969730ad7a59b132aff79fd02d515b379'
